<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <!-- BEGIN: Head-->
    <head>
    
    <title>403 FORBIDDEN</title>
  
    </head>
  <!-- END: Head-->
    <body >
      <section class="container" style="width: 60%;margin: auto;padding-top: 30px;">
        <div
        style="height:14px;background-color: #e20000;border-top-left-radius: 30px !important;border-top-right-radius: 30px !important;">
        <section
        style="margin: auto;text-align: center;box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;border-top-left-radius: 14px !important;border-top-right-radius: 14px !important;">
        <div style="margin: auto;padding-top: 50px;">
        <img src="{{ asset('assets/frontend/images/lock.png')}}" style="margin: auto; width: 260px;" alt="" srcset="">
        </div>
        <div class="robotoMedium" style="font-size: 55px;padding-top: 16px;color: #e20000;">403 FORBIDDEN </div>
        
        <div class="robotoRegula"
        style="font-size: 21px;max-width: 500px;text-align: center;margin: auto; padding-top: 16px;border-bottom: 1px solid #707070;padding-bottom: 30px;">
        
        Your Profile is under view and administrator will approved your profile as soon as possible
        </div>
        <div style="padding-bottom: 60px;"></div>
        
        <!-- <div class=" robotoRegular" style="padding-top: 16px;padding-bottom: 60px;"><button type="button"
        style="padding-left: 42px;padding-right: 42px;padding-top: 12px;padding-bottom: 12px;border-radius: 4px;border: 0px ;background-color: #e20000;color: #ffffff !important;"><a
        href="" style="text-decoration: none;color: #ffffff;">Login</a></button></div> -->
        </section>
        </div>
        
        
        
        </section>
  </body>
</html>