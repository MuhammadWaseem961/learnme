@extends('layouts.frontend.app')
@section('title','index')
{{-- head start --}}
	
	@section('extra-css')

	

	@endsection
{{-- head end --}}


{{-- content section start --}}

	@section('content')
		
		

	@endsection

{{-- content section end --}}

{{-- footer section start --}}


	@section('extra-script')

	@endsection

{{-- footer section end --}}

