@extends('layouts.frontend.setting') @section('title','Posts') {{-- head start --}} @section('extra-css')
<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/css/dashboard.css') }}" />
<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/css/register.css') }}" />
<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/css/login_register_common.css') }}" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
{{-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
    integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous"> --}}
<style type="text/css">
.dropdown-toggle::after {
    display: none;
}

body {
    background-image: none;
}

.nav-pills .nav-link.active {
    background-color: #3ac574 !important;
}




.px-50 {
    padding-left: 50px !important;
    padding-right: 50px !important;
}
</style>
@endsection {{-- head end --}} {{-- content section start --}}
@section('navbar')

<section class="px-5 pt-2 pb-2 nav-bg-img robotoRegular">@include('includes.frontend.navbar')</section>
@include('includes.frontend.navigations')
@endsection
@section('content')


<p class="border-bottom pl-3 f-21 cl-616161">My Blog Posts</p>
<a href="{{ route('posts.create') }}" title="Click to Add Post" class="mr-3 btn btn-sm bg-3AC574 text-white m-2 add_service"
    style="float: right;">Add Blog Post</a>
<div class="table-responsive ServiceTableData px-3 mb-3" id="ServiceTableData">
    <table id="example1" class="table table-hover example1" style="width:100%;">
        <thead>
            <tr class="text-uppercase">
                <th class="wsnw">No #</th>
                <th scope="col">Title</th>
                <th scope="col">Image</th>
                {{-- <th scope="col">Summary</th> --}}
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            @if($posts->count()>0)
                @foreach($posts as $key=>$post)
                    <tr>
                        <td class="h5 m-0 va-middle">{{++$key}}</td>
                        <td class="va-middle">{{ $post->title }}</td>
                        <td class="va-middle"><img src="{{ asset($post->image) }}" width="100" height="100"></td>
                        {{-- <td class="va-middle">{{Str::limit($post->desciption, 50,'...')}}</td> --}}
                        <td class="va-middle">
                            <div class="d-flex">
                                <a class="btn btn-info btn-sm ml-1" href="{{route('posts.show',$post->id)}}" title="View Blog Post">View</a>
                                <a class="btn btn-success btn-sm ml-1" href="{{route('posts.edit',$post->id)}}" title="Edit Blog Post">Edit</a>
                                <button class="btn btn-danger btn-sm ml-1" title="Delete Blog Post" onclick="delete_resource('{{ route('posts.destroy',$post->id) }}','{{ route('posts.index') }}')">Delete</button>
                            </div>
                        </td>
                    </tr>
                @endforeach
            @endif
            

        </tbody>
    </table>
</div>

<!-- Modal For Deleting Service-->
<div class="modal fade deleteServiceModal" id="deleteServiceModal" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabelServicedelete" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabelServicedelete" style="font-size: 18px !important;">
                    Delete Confirmation !</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure, you want to delete this Service?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-md btn-danger" data-dismiss="modal">No, Cancel</button>
                <button type="button" class="btn btn-md btn-primary deleteServiceBtn" id="deleteServiceBtn"
                    data-dismiss="modal">Yes, Delete</button>
            </div>
        </div>
    </div>
</div>

@endsection
{{-- footer section start --}} @section('extra-script')


<script>
function addService() {
    var myform = document.getElementById("addService");
    var fd = new FormData(myform);
    fd.append("_token", "{{ csrf_token() }}");
    $.ajax({
        url: "{{ route('services.store') }}",
        type: "post",
        processData: false,
        contentType: false,
        data: fd,
        success: function(data) {
            if (data.success == true) {
                swal("success", data.message, "success").then((value) => {
                    $(".close");
                    window.location = '{{ route("services.index") }}';
                });
            } else {
                if (data.hasOwnProperty("message")) {
                    var wrapper = document.createElement("div");
                    var err = "";
                    $.each(data.message, function(i, e) {
                        err += "<p>" + e + "</p>";
                    });

                    wrapper.innerHTML = err;
                    swal({
                        icon: "error",
                        text: "{{ __('Please fix following error!') }}",
                        content: wrapper,
                        type: "error",
                    });
                    //setTimeout("pageRedirect()", 3000);
                    //$('.actions  li:first-child a').click();
                }
            }
        },
    });
}

function delete_resource(target_url,return_url){
    swal({
        text: 'Are you sure you want to delete?',
        icon: "warning",
        buttons: {
            cancel: "Cancel",
            confirm: "OK"
            },
    }).then((willDelete) => {
        if (willDelete)
        { 
            $.ajax({
                type: 'post',
                url: target_url,
                data: {
                    _token: '{{ csrf_token() }}',
                    _method:"delete"
                },
                success: function(data) {
                    swal("success", data.message, "success").then((value) => {
                        window.location = return_url;
                    });  
                }
            });
        } 
    });
}
</script>
@endsection {{-- footer section end --}}