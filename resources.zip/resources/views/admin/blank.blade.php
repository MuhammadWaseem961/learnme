@extends('layouts.admin.app')
@section('title','Admin |Dashboard ') 
@section('content')
@endsection
