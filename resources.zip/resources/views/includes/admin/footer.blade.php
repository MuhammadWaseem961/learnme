<section class="main_padding bg-4b4b4b4 mt-5 pt-4 pb-4">
  <div class="d-flex justify-content-center  align-items-center">
    <img src="{{ asset('assets/frontend/images/Copyright © 2021 learnmelive, All Right Reserved learnmelive.png') }}"
          alt="" srcset="">
  </div>
</section>
    