	<footer class="page-footer footer footer-static footer-dark gradient-45deg-indigo-purple gradient-shadow navbar-border navbar-shadow">
      <div class="footer-copyright">
        <div class="container"><span>&copy; {{ date('Y') }}         <a href="http://themeforest.net/user/pixinvent/portfolio?ref=pixinvent" target="_blank">Estore</a> All rights reserved.</span>
        	{{-- <span class="right hide-on-small-only">Design and Developed by <a href="https://pixinvent.com/">EWDTECH</a></span> --}}
        </div>
      </div>
    </footer>

    <!-- END: Footer-->

    